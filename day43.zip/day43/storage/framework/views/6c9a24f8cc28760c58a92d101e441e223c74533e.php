<h1>hIIIIII</h1>
<?php /**PATH C:\xampp\htdocs\day43\resources\views/admin/product/details.blade.php ENDPATH**/ ?>