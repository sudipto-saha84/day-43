@extends('admin.master')

@section('title')
    {{env('APP_NAME')}}-manage
@endsection

@section('body')
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-10 mx-auto card">
                    <div class="card-header bg-danger">
                        <h4>All Products</h4>
                    </div>
                    <div class="card-body">
                        <table class="table" id="dataTable" >

                            <thead>
                            <tr>
                                <td>#</td>
                                <td>Product Name</td>
                                <td>Category Name</td>
                                <td>Brand Name</td>
                                <td>Price</td>
                                <td>Image</td>
                                <td>Description</td>
                                <td>Status</td>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($products as $product)

                                <tr>
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$product->product_name}}</td>
                                    <td>{{$product->category_name}}</td>
                                    <td>{{$product->brand_name}}</td>
                                    <td>{{$product->product_price}}</td>
                                    <td>
                                        <img src="{{asset($product->product_image)}}" alt="" style="height: 100px;width: 100px;">
                                    </td>
                                    <td>{!! substr_replace($product->description,'read more',160) !!}</td>
                                    <td>{{$product->status==1 ?'Published' :'Unpublished'}}</td>
                                </tr>
                            @endforeach
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
